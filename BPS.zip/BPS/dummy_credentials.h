/*
 * Rename this file credentials.h
 * and edit to suit your circumstances
 */
const char* ssid = "";             //Wifi network SSID
const char* password = "";         // Password
const char* Host = "BPS32";
const char* MQ_client = "BPStest"; // your MQTT Client ID
const char* MQ_user = "";          // your MQTT password
const char* MQ_pass = "";          // your network password
const char* mqtt_server = "192.168.0.4";
