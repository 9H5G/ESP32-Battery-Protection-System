/*  32600
 *   
 *   Implement hold-on to all relays with pulseDelay = 0
 *   Added Temperature warnings and cutoffs
 */
