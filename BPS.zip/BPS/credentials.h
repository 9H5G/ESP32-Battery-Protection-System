/*
 * Credentials here
 * 
 */
 
const char* ssid = "agboat_s";
const char* password = "jram7757";
const char* Host = "BPS32";
const char* MQ_client = "BPS";           // your MQTT Client ID
const char* MQ_user = "jramacrae";       // your MQTT password
const char* MQ_pass = "jram7757";        // your network password
const char* mqtt_server = "192.168.199.8";
